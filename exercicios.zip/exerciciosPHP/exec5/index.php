<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fatorial</title>
</head>
<body>
    <form  method="post" action="index.php">
        
        <p>Nota 1: <input type="number" name="val1" max="10" min="0"></p>
        <p>Nota 2: <input type="number" name="val2" max="10" min="0"></p>
        <p>Nota 3: <input type="number" name="val3" max="10" min="0"></p>

        <input type="submit" value="enviar">
        
    </form>

    <br/>
</body>
</html>
<?php

    $notas = array($_POST['val1'], $_POST['val2'], $_POST['val3']);
    $media = ($notas[0] + $notas[1] + $notas[2]) /3;

    echo "A média do aluno foi $media .";
    echo "<br/>";

    if ($media >= 6){
        echo "O aluno foi aprovado.";
    } else{
        echo "O aluno foi reprovado.";
    }
?>