<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fatorial</title>
</head>
<body>
    <form  method="post" action="index.php">
        
        <p><input type="number" name="numero"></p>

        <input type="submit" value="enviar">
        
    </form>

    <br/>
</body>
</html>
<?php
    $valor = $_POST['numero'];
    $fatorial = 1;
    
    for($cont=1; $cont<=$valor; $cont++)
        $fatorial *= $cont;

        echo $fatorial;
?>